# challenge

## Setup

1. Go to project folder
> cd challenge

2. Install Dependencies
> npm install

## Run

1. Start Server
> npm start

2. Open in url or using an Endpoint tester (postman)

Apis docs for examples.

http://localhost:3333/api-docs
